### Tip-Calculator With DropDown
---
**Newton School Project**
------------------
- HTML
- CSS
- JavaScript
<img align="center" src="https://user-images.githubusercontent.com/74202040/155593110-dfcba170-1179-459f-9be7-56b75c69ba2a.jpg">
